<?php
// Datos de conexión local con XAMPP
$host = "sql302.infinityfree.com";
$usuario = "if0_42413497";
$password = "oTM8jzIR9T3C4Pd";
$base_datos = "if0_42413497_clin";

// Crear conexión con MySQL
$conexion = mysqli_connect($host, $usuario, $password, $base_datos);

// Verificar si hubo error en la conexión
if (!$conexion) {
    die("Error de conexión: " . mysqli_connect_error());
}

// Permite usar correctamente acentos y caracteres especiales
mysqli_set_charset($conexion, "utf8");
?>
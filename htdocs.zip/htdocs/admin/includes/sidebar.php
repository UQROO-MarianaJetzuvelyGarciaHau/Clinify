<aside class="sidebar">

    <!-- Nombre del sistema y rol -->
    <div class="logo-admin">

        <a href="/admin/dashboard.php">
            Clinify
        </a>

        <span>
            <?php
            echo htmlspecialchars(
                $_SESSION['rol'] ?? ''
            );
            ?>
        </span>

    </div>

    <!-- Menú principal -->
    <nav class="menu-admin">

        <a href="/admin/dashboard.php">
            Dashboard
        </a>

        <!-- Administrador y Asistente -->
        <a href="/admin/plan/planes.php">
            Planes
        </a>

        <a href="/admin/caracteristicas/caracteristicas.php">
            Características
        </a>

        <a href="/admin/contactos/contactos.php">
            Contactos
        </a>

        <!-- Opciones exclusivas del Administrador -->
        <?php if (esAdministrador()) { ?>

            <a href="/admin/equipo/equipo.php">
                Equipo
            </a>

            <a href="/admin/usuario/usuarios.php">
                Perfiles
            </a>

        <?php } ?>

    </nav>

    <!-- Información del usuario -->
    <div class="sidebar-pie">

        <p>
            <?php
            echo htmlspecialchars(
                $_SESSION['usuario_nombre'] ?? ''
            );
            ?>
        </p>

        <span class="rol-usuario">
            <?php
            echo htmlspecialchars(
                $_SESSION['rol'] ?? ''
            );
            ?>
        </span>

        <a
            href="../../index.php"
            class="enlace-sitio">

            Ver sitio público

        </a>

        <a
            href="/admin/actions/cerrar_sesion.php"
            class="cerrar-sesion">

            Cerrar sesión

        </a>

    </div>

</aside>
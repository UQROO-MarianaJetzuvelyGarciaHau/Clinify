

/* =========================================
   VALIDACIÓN DEL FORMULARIO DE CONTACTO
========================================= */

const formularioContacto = document.querySelector(
    ".formulario-contacto"
);

if (formularioContacto) {
    formularioContacto.addEventListener(
        "submit",
        function (evento) {
            /*
            Aunque HTML valida el teléfono, hacemos una
            segunda comprobación sencilla con JavaScript.
            */
            const telefono = document
                .getElementById("telefono")
                .value
                .trim();

            if (!/^\d{10}$/.test(telefono)) {
                alert(
                    "El teléfono debe contener exactamente 10 dígitos."
                );

                evento.preventDefault();
            }
        }
    );
}


/* =========================================
   NOTIFICACIÓN TOAST
========================================= */

const toast = document.getElementById("toast");

if (toast) {
    /*
    Esperar tres segundos antes de comenzar
    a ocultar la notificación.
    */
    setTimeout(() => {
        toast.style.opacity = "0";
        toast.style.transform = "translateY(-1rem)";
        toast.style.transition = "0.5s ease";

        /*
        Eliminar el elemento después de completar
        la transición visual.
        */
        setTimeout(() => {
            toast.remove();

            /*
            Quitar ?mensaje=exito o ?mensaje=error
            para que el toast no vuelva al recargar.
            */
            window.history.replaceState(
                {},
                document.title,
                window.location.pathname
            );
        }, 500);

    }, 3000);
}

